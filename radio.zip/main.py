from PyQt5.QtCore import QUrl
from PyQt5.QtWidgets import QMainWindow, QApplication, QMessageBox
from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent
from PyQt5.uic import loadUi
from sys import argv, exit
from add import AddWindow
from choose import ChooseWindow


class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.index = None
        loadUi('main.ui', self)
        self.player = QMediaPlayer()
        self.stations = []
        self.volume = 50
        self.update_volume()
        self.player.setVolume(self.volume)
        self.choose()
        self.add_station.clicked.connect(self.add)
        self.change_station.clicked.connect(self.choose)
        self.vol_up.clicked.connect(self.volume_up)
        self.vol_down.clicked.connect(self.volume_down)
        self.play_btn.clicked.connect(self.play)
        self.pause_btn.clicked.connect(self.pause)
        self.switch_left_btn.clicked.connect(self.switch_left)
        self.switch_right_btn.clicked.connect(self.switch_right)
        self.player.error.connect(self.handle_error)

    def handle_error(self, error):
        msg = QMessageBox()
        msg.setIcon(msg.critical)
        msg.setText(error)
        msg.exec_()
        self.close()

    def volume_up(self):
        self.volume += 5
        if self.volume > 100:
            self.volume = 100
        self.player.setVolume(self.volume)
        self.update_volume()

    def update_volume(self):
        self.volume_label.setText(str(self.volume))

    def volume_down(self):
        self.volume -= 5
        if self.volume < 0:
             self.volume = 0
        self.player.setVolume(self.volume)
        self.update_volume()

    def add(self):
        a = AddWindow()
        a.exec_()

    def choose(self):
        choose_window = ChooseWindow()
        choose_window.station.connect(self.handle)
        choose_window.exec_()

    def play(self):
        self.player.play()

    def pause(self):
        self.player.pause()

    def handle(self, index, stations, flag):
        if flag:
            self.index = index
            self.stations = stations
            self.set()

    def set(self):
        self.statusBar().showMessage(self.stations[self.index][0])
        media_content = QMediaContent(QUrl(self.stations[self.index][-1]))
        if media_content.isNull():
            print("Ошибка: Не удалось установить медиаконтент")
        else:
            self.player.setMedia(media_content)
            self.play()
        self.play()

    def switch_left(self):
        self.index -= 1
        if self.index < 0:
            self.index = len(self.stations) - 1
        self.set()

    def switch_right(self):
        self.index += 1
        if self.index >= len(self.stations):
            self.index = 0
        self.set()


if __name__ == '__main__':
    app = QApplication(argv)
    main = Main()
    main.show()
    exit(app.exec_())
